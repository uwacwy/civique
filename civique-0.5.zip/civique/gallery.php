<?php get_header(); ?>

<section class="stripe stripe-content padded">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php get_template_part('loop'); ?>
			</div>
		</div>
	</div>
</section>

<?php get_footer(); ?>