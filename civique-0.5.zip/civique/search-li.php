<li class="search-li">
	<?php get_search_form(); ?>
</li>