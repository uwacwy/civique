<?php

//
//	content-post.php
//	--
//	blog post template.php
//

?>
here a post tho